namespace TrainSwitching.Logic;

public class Track
{
    public List<int> Wagons { get; } = [];
}