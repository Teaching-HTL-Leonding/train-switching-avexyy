namespace TrainSwitching.Logic;

public static class SwitchingOperationParser
{
    /// <summary>
    /// Parses a line of input into a <see cref="SwitchingOperation"/>.
    /// </summary>
    /// <param name="inputLine">Line to parse. See readme.md for details</param>
    /// <returns>The parsed switching operation</returns>
    public static SwitchingOperation Parse(string inputLine)
    {
        var result = new SwitchingOperation();

        var part = inputLine.Split(", ");

        result.TrackNumber = int.Parse(part[0].Split(" ")[2]);

        if (part[1].StartsWith("add")) { result.OperationType = Constants.OPERATION_ADD; }
        else if (part[1].StartsWith("remove")) { result.OperationType = Constants.OPERATION_REMOVE; }
        else if (part[1].StartsWith("train leaves")) { result.OperationType = Constants.OPERATION_TRAIN_LEAVE; }

        if (part[1].EndsWith("West")) { result.Direction = Constants.DIRECTION_WEST; }
        else if (part[1].EndsWith("East")) { result.Direction = Constants.DIRECTION_EAST; }

        if (result.OperationType == Constants.OPERATION_ADD)
        {
            if(part[1].Contains("Locomotive")) { result.WagonType = Constants.WAGON_TYPE_LOCOMOTIVE; }
            else if(part[1].Contains("Passenger")) { result.WagonType = Constants.WAGON_TYPE_PASSENGER; }
            else if(part[1].Contains("Freight")) { result.WagonType = Constants.WAGON_TYPE_FREIGHT; }
            else if(part[1].Contains("Car Transport")) { result.WagonType = Constants.WAGON_TYPE_CAR_TRANSPORT; }
        }

        if (result.OperationType == Constants.OPERATION_REMOVE)
        {
            result.NumberOfWagons = int.Parse(part[1].Split(" ")[1]);
        }

        return result;
    }
}